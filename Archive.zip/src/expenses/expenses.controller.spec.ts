import { Test, TestingModule } from '@nestjs/testing';
import { ExpensesController } from './expenses.controller';
import { ExpensesService } from './expenses.service';
import { ExpenseCategory, PaymentStatus } from '../entities/expense.entity';
import { CreateExpenseDto } from './dto/create-expense.dto';
import { UpdateExpenseDto } from './dto/update-expense.dto';

describe('ExpensesController', () => {
  let controller: ExpensesController;
  let service: ExpensesService;

  const mockExpensesService = {
    create: jest.fn(),
    findAll: jest.fn(),
    findOne: jest.fn(),
    update: jest.fn(),
    remove: jest.fn(),
    findByCategory: jest.fn(),
    findByDateRange: jest.fn(),
    getExpenseSummary: jest.fn(),
    getExpenseTrend: jest.fn(),
    getExpenseForecast: jest.fn(),
    approveExpense: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ExpensesController],
      providers: [
        {
          provide: ExpensesService,
          useValue: mockExpensesService,
        },
      ],
    }).compile();

    controller = module.get<ExpensesController>(ExpensesController);
    service = module.get<ExpensesService>(ExpensesService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('getExpenseSummary', () => {
    it('should return expense summary', async () => {
      const startDate = '2024-01-01';
      const endDate = '2024-01-31';
      const mockSummary = {
        totalExpenses: 600,
        totalCount: 3,
        averageExpense: 200,
        minExpense: 100,
        maxExpense: 300,
        categoryBreakdown: [],
        dateRange: { startDate: new Date(startDate), endDate: new Date(endDate) },
        paymentStatusBreakdown: {
          pending: 1,
          paid: 1,
          cancelled: 1,
        },
      };

      mockExpensesService.getExpenseSummary.mockResolvedValue(mockSummary);

      const result = await controller.getExpenseSummary(startDate, endDate);

      expect(result).toEqual(mockSummary);
      expect(service.getExpenseSummary).toHaveBeenCalledWith(
        new Date(startDate),
        new Date(endDate),
      );
    });
  });

  describe('getExpenseTrend', () => {
    it('should return expense trend data', async () => {
      const startDate = '2024-01-01';
      const endDate = '2024-01-31';
      const interval = 'day';
      const mockTrend = {
        interval: 'day',
        data: [],
        dateRange: { startDate: new Date(startDate), endDate: new Date(endDate) },
        summary: {
          totalAmount: 300,
          totalCount: 2,
          averageAmount: 150,
          trend: 0,
        },
      };

      mockExpensesService.getExpenseTrend.mockResolvedValue(mockTrend);

      const result = await controller.getExpenseTrend(startDate, endDate, interval);

      expect(result).toEqual(mockTrend);
      expect(service.getExpenseTrend).toHaveBeenCalledWith(
        new Date(startDate),
        new Date(endDate),
        interval,
      );
    });

    it('should use default interval if not provided', async () => {
      const startDate = '2024-01-01';
      const endDate = '2024-01-31';
      const mockTrend = {
        interval: 'month',
        data: [],
        dateRange: { startDate: new Date(startDate), endDate: new Date(endDate) },
        summary: {
          totalAmount: 300,
          totalCount: 2,
          averageAmount: 150,
          trend: 0,
        },
      };

      mockExpensesService.getExpenseTrend.mockResolvedValue(mockTrend);

      const result = await controller.getExpenseTrend(startDate, endDate);

      expect(result).toEqual(mockTrend);
      expect(service.getExpenseTrend).toHaveBeenCalledWith(
        new Date(startDate),
        new Date(endDate),
        'month',
      );
    });
  });

  describe('getExpenseForecast', () => {
    it('should return expense forecast', async () => {
      const startDate = '2024-01-01';
      const endDate = '2024-01-31';
      const mockForecast = {
        historicalData: [],
        forecast: [],
        dateRange: { startDate: new Date(startDate), endDate: new Date(endDate) },
        summary: {
          averageAmount: 150,
          predictedAverage: 150,
          trend: 0,
          confidence: 0.7,
        },
      };

      mockExpensesService.getExpenseForecast.mockResolvedValue(mockForecast);

      const result = await controller.getExpenseForecast(startDate, endDate);

      expect(result).toEqual(mockForecast);
      expect(service.getExpenseForecast).toHaveBeenCalledWith(
        new Date(startDate),
        new Date(endDate),
      );
    });
  });

  describe('findByCategory', () => {
    it('should return expenses by category', async () => {
      const category = ExpenseCategory.MAINTENANCE;
      const mockExpenses = [
        {
          _id: '1',
          title: 'Test Expense',
          amount: 100,
          category: ExpenseCategory.MAINTENANCE,
          paymentStatus: PaymentStatus.PENDING,
          date: new Date(),
        },
      ];

      mockExpensesService.findByCategory.mockResolvedValue(mockExpenses);

      const result = await controller.findByCategory(category);

      expect(result).toEqual(mockExpenses);
      expect(service.findByCategory).toHaveBeenCalledWith(category);
    });
  });

  describe('findByDateRange', () => {
    it('should return expenses within date range', async () => {
      const startDate = '2024-01-01';
      const endDate = '2024-01-31';
      const mockExpenses = [
        {
          _id: '1',
          title: 'Test Expense',
          amount: 100,
          category: ExpenseCategory.MAINTENANCE,
          paymentStatus: PaymentStatus.PENDING,
          date: new Date(),
        },
      ];

      mockExpensesService.findByDateRange.mockResolvedValue(mockExpenses);

      const result = await controller.findByDateRange(startDate, endDate);

      expect(result).toEqual(mockExpenses);
      expect(service.findByDateRange).toHaveBeenCalledWith(
        new Date(startDate),
        new Date(endDate),
      );
    });
  });
}); 