import { Test, TestingModule } from '@nestjs/testing';
import { getModelToken } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { ExpensesService } from './expenses.service';
import { Expense, PaymentStatus, ExpenseCategory } from '../entities/expense.entity';
import { NotFoundException, BadRequestException } from '@nestjs/common';

describe('ExpensesService', () => {
  let service: ExpensesService;
  let model: Model<Expense>;

  const mockExpenseModel = {
    find: jest.fn(),
    findById: jest.fn(),
    findByIdAndUpdate: jest.fn(),
    findByIdAndDelete: jest.fn(),
    aggregate: jest.fn(),
    save: jest.fn(),
  };

  const mockExpenses = [
    {
      _id: '1',
      title: 'Test Expense 1',
      amount: 100,
      category: ExpenseCategory.MAINTENANCE,
      paymentStatus: PaymentStatus.PENDING,
      date: new Date('2024-01-01'),
      createdBy: 'user1',
    },
    {
      _id: '2',
      title: 'Test Expense 2',
      amount: 200,
      category: ExpenseCategory.UTILITIES,
      paymentStatus: PaymentStatus.PAID,
      date: new Date('2024-01-02'),
      createdBy: 'user2',
    },
    {
      _id: '3',
      title: 'Test Expense 3',
      amount: 300,
      category: ExpenseCategory.MAINTENANCE,
      paymentStatus: PaymentStatus.CANCELLED,
      date: new Date('2024-01-03'),
      createdBy: 'user1',
    },
  ];

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        ExpensesService,
        {
          provide: getModelToken(Expense.name),
          useValue: mockExpenseModel,
        },
      ],
    }).compile();

    service = module.get<ExpensesService>(ExpensesService);
    model = module.get<Model<Expense>>(getModelToken(Expense.name));
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('getExpenseSummary', () => {
    it('should return expense summary with correct calculations', async () => {
      const startDate = new Date('2024-01-01');
      const endDate = new Date('2024-01-31');

      mockExpenseModel.find.mockReturnValue({
        exec: jest.fn().mockResolvedValue(mockExpenses),
      });

      mockExpenseModel.aggregate.mockResolvedValue([
        {
          category: ExpenseCategory.MAINTENANCE,
          totalAmount: 400,
          count: 2,
          averageAmount: 200,
          minAmount: 100,
          maxAmount: 300,
          paymentStatusBreakdown: {
            pending: 1,
            paid: 0,
            cancelled: 1,
          },
        },
        {
          category: ExpenseCategory.UTILITIES,
          totalAmount: 200,
          count: 1,
          averageAmount: 200,
          minAmount: 200,
          maxAmount: 200,
          paymentStatusBreakdown: {
            pending: 0,
            paid: 1,
            cancelled: 0,
          },
        },
      ]);

      const result = await service.getExpenseSummary(startDate, endDate);

      expect(result).toEqual({
        totalExpenses: 600,
        totalCount: 3,
        averageExpense: 200,
        minExpense: 100,
        maxExpense: 300,
        categoryBreakdown: expect.any(Array),
        dateRange: { startDate, endDate },
        paymentStatusBreakdown: {
          pending: 1,
          paid: 1,
          cancelled: 1,
        },
      });
    });
  });

  describe('getExpenseTrend', () => {
    it('should return expense trend data with correct calculations', async () => {
      const startDate = new Date('2024-01-01');
      const endDate = new Date('2024-01-31');

      mockExpenseModel.aggregate.mockResolvedValueOnce([
        {
          date: new Date('2024-01-01'),
          totalAmount: 100,
          count: 1,
          averageAmount: 100,
        },
        {
          date: new Date('2024-01-02'),
          totalAmount: 200,
          count: 1,
          averageAmount: 200,
        },
      ]);

      mockExpenseModel.aggregate.mockResolvedValueOnce([
        {
          totalAmount: 150,
          count: 1,
          averageAmount: 150,
        },
      ]);

      mockExpenseModel.aggregate.mockResolvedValueOnce([
        {
          totalAmount: 300,
          count: 2,
          averageAmount: 150,
        },
      ]);

      const result = await service.getExpenseTrend(startDate, endDate, 'day');

      expect(result).toEqual({
        interval: 'day',
        data: expect.any(Array),
        dateRange: { startDate, endDate },
        summary: {
          totalAmount: 300,
          totalCount: 2,
          averageAmount: 150,
          trend: 0, // (150 - 150) / 150 = 0
        },
      });
    });
  });

  describe('getExpenseForecast', () => {
    it('should return expense forecast with confidence intervals', async () => {
      const startDate = new Date('2024-01-01');
      const endDate = new Date('2024-01-31');

      mockExpenseModel.aggregate.mockResolvedValue([
        {
          date: new Date('2024-01-01'),
          amount: 100,
        },
        {
          date: new Date('2024-01-02'),
          amount: 200,
        },
      ]);

      const result = await service.getExpenseForecast(startDate, endDate);

      expect(result).toEqual({
        historicalData: expect.any(Array),
        forecast: expect.any(Array),
        dateRange: { startDate, endDate },
        summary: {
          averageAmount: 150,
          predictedAverage: 150,
          trend: 0,
          confidence: 0.7,
        },
      });

      // Verify forecast points
      expect(result.forecast.length).toBe(30);
      expect(result.forecast[0]).toEqual({
        date: expect.any(Date),
        predictedAmount: 150,
        confidenceInterval: {
          lower: 135, // 150 - (150 * 0.1)
          upper: 165, // 150 + (150 * 0.1)
        },
      });
    });
  });

  describe('approveExpense', () => {
    it('should approve an expense and update its status', async () => {
      const expenseId = '1';
      const approverId = 'admin1';
      const mockExpense = {
        ...mockExpenses[0],
        save: jest.fn().mockResolvedValue({
          ...mockExpenses[0],
          approvedBy: approverId,
          paymentStatus: PaymentStatus.PAID,
        }),
      };

      mockExpenseModel.findById.mockReturnValue({
        exec: jest.fn().mockResolvedValue(mockExpense),
      });

      const result = await service.approveExpense(expenseId, approverId);

      expect(result).toEqual({
        ...mockExpense,
        approvedBy: approverId,
        paymentStatus: PaymentStatus.PAID,
      });
      expect(mockExpense.save).toHaveBeenCalled();
    });

    it('should throw NotFoundException if expense not found', async () => {
      mockExpenseModel.findById.mockReturnValue({
        exec: jest.fn().mockResolvedValue(null),
      });

      await expect(service.approveExpense('1', 'admin1')).rejects.toThrow(
        NotFoundException,
      );
    });

    it('should throw BadRequestException if expense is already paid', async () => {
      const paidExpense = {
        ...mockExpenses[0],
        paymentStatus: PaymentStatus.PAID,
      };

      mockExpenseModel.findById.mockReturnValue({
        exec: jest.fn().mockResolvedValue(paidExpense),
      });

      await expect(service.approveExpense('1', 'admin1')).rejects.toThrow(
        BadRequestException,
      );
    });
  });
}); 