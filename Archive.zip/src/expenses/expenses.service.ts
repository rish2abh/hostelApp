import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Schema as MongooseSchema } from 'mongoose';
import { Expense, ExpenseStatus } from '../entities/expense.entity';
import { CreateExpenseDto } from './dto/create-expense.dto';
import { UpdateExpenseDto } from './dto/update-expense.dto';
import { ExpenseSummaryDto, CategorySummaryDto } from './dto/expense-summary.dto';
import { ExpenseTrendDto, ExpenseTrendPointDto } from './dto/expense-trend.dto';
import { ExpenseForecastDto, ExpenseForecastPointDto } from './dto/expense-forecast.dto';

interface FindAllParams {
  status?: string;
  category?: string;
  roomId?: string;
  startDate?: Date;
  endDate?: Date;
  page?: number;
  limit?: number;
}

@Injectable()
export class ExpensesService {
  constructor(
    @InjectModel(Expense.name) private expenseModel: Model<Expense>,
  ) {}

  async create(createExpenseDto: CreateExpenseDto, userId: string) {
    const expense = new this.expenseModel({
      ...createExpenseDto,
      createdBy: new MongooseSchema.Types.ObjectId(userId),
    });
    return expense.save();
  }

  async findAll(params: FindAllParams): Promise<{ data: Expense[]; total: number; page: number; limit: number }> {
    const { status, category, roomId, startDate, endDate, page = 1, limit = 10 } = params;
    const query: any = {};

    if (status) query.status = status;
    if (category) query.category = category;
    if (roomId) query.roomId = roomId;
    if (startDate || endDate) {
      query.expenseDate = {};
      if (startDate) query.expenseDate.$gte = startDate;
      if (endDate) query.expenseDate.$lte = endDate;
    }

    const skip = (page - 1) * limit;
    
    const [data, total] = await Promise.all([
      this.expenseModel
        .find(query)
        .skip(skip)
        .limit(limit)
        .exec(),
      this.expenseModel.countDocuments(query),
    ]);

    return {
      data,
      total,
      page: Number(page),
      limit: Number(limit),
    };
  }

  async findOne(id: string) {
    const expense = await this.expenseModel
      .findById(id)
      .populate('createdBy', 'firstName lastName email')
      .populate('approvedBy', 'firstName lastName email')
      .populate('relatedRoom', 'roomNumber');

    if (!expense) {
      throw new NotFoundException('Expense not found');
    }

    return expense;
  }

  async update(id: string, updateExpenseDto: UpdateExpenseDto) {
    const expense = await this.expenseModel
      .findByIdAndUpdate(id, updateExpenseDto, { new: true })
      .populate('createdBy', 'firstName lastName email')
      .populate('approvedBy', 'firstName lastName email')
      .populate('relatedRoom', 'roomNumber');

    if (!expense) {
      throw new NotFoundException('Expense not found');
    }

    return expense;
  }

  async remove(id: string) {
    const expense = await this.expenseModel.findById(id);
    if (!expense) {
      throw new NotFoundException('Expense not found');
    }

    await this.expenseModel.findByIdAndDelete(id);
    return { message: 'Expense deleted successfully' };
  }

  async findByCategory(category: string) {
    return this.expenseModel
      .find({ category })
      .populate('createdBy', 'firstName lastName email')
      .populate('approvedBy', 'firstName lastName email')
      .populate('relatedRoom', 'roomNumber')
      .sort({ date: -1 });
  }

  async findByDateRange(startDate: Date, endDate: Date) {
    return this.expenseModel
      .find({
        date: {
          $gte: startDate,
          $lte: endDate,
        },
      })
      .populate('createdBy', 'firstName lastName email')
      .populate('approvedBy', 'firstName lastName email')
      .populate('relatedRoom', 'roomNumber')
      .sort({ date: -1 });
  }

  async approveExpense(id: string, approverId: string) {
    const expense = await this.expenseModel.findById(id);
    if (!expense) {
      throw new NotFoundException('Expense not found');
    }

    if (expense.status !== ExpenseStatus.PENDING) {
      throw new BadRequestException('Expense is already approved');
    }

    expense.approvedBy = new MongooseSchema.Types.ObjectId(approverId);
    expense.status = ExpenseStatus.APPROVED;
    return expense.save();
  }

  async getExpenseSummary(
    startDate: Date,
    endDate: Date,
  ): Promise<ExpenseSummaryDto> {
    const expenses = await this.expenseModel.find({
      date: { $gte: startDate, $lte: endDate },
    });

    const categoryBreakdown = await this.expenseModel.aggregate([
      {
        $match: {
          date: { $gte: startDate, $lte: endDate },
        },
      },
      {
        $group: {
          _id: '$category',
          totalAmount: { $sum: '$amount' },
          count: { $sum: 1 },
          averageAmount: { $avg: '$amount' },
          minAmount: { $min: '$amount' },
          maxAmount: { $max: '$amount' },
          paymentStatusBreakdown: {
            $push: '$status',
          },
        },
      },
      {
        $project: {
          _id: 0,
          category: '$_id',
          totalAmount: 1,
          count: 1,
          averageAmount: 1,
          minAmount: 1,
          maxAmount: 1,
          paymentStatusBreakdown: {
            pending: {
              $size: {
                $filter: {
                  input: '$paymentStatusBreakdown',
                  as: 'status',
                  cond: { $eq: ['$$status', 'pending'] },
                },
              },
            },
            approved: {
              $size: {
                $filter: {
                  input: '$paymentStatusBreakdown',
                  as: 'status',
                  cond: { $eq: ['$$status', 'approved'] },
                },
              },
            },
            rejected: {
              $size: {
                $filter: {
                  input: '$paymentStatusBreakdown',
                  as: 'status',
                  cond: { $eq: ['$$status', 'rejected'] },
                },
              },
            },
          },
        },
      },
    ]);

    const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
    const paymentStatusBreakdown = expenses.reduce(
      (acc, expense) => {
        acc[expense.status]++;
        return acc;
      },
      { pending: 0, approved: 0, rejected: 0 },
    );

    return {
      totalExpenses,
      totalCount: expenses.length,
      averageExpense: totalExpenses / expenses.length || 0,
      minExpense: Math.min(...expenses.map(e => e.amount)),
      maxExpense: Math.max(...expenses.map(e => e.amount)),
      categoryBreakdown,
      dateRange: { startDate, endDate },
      paymentStatusBreakdown,
    };
  }

  async getExpenseTrend(
    startDate: Date,
    endDate: Date,
    interval: 'day' | 'week' | 'month' = 'month',
  ): Promise<ExpenseTrendDto> {
    const groupBy = {
      day: { $dateToString: { format: '%Y-%m-%d', date: '$date' } },
      week: { $dateToString: { format: '%Y-W%V', date: '$date' } },
      month: { $dateToString: { format: '%Y-%m', date: '$date' } },
    }[interval];

    const trendData = await this.expenseModel.aggregate([
      {
        $match: {
          date: { $gte: startDate, $lte: endDate },
        },
      },
      {
        $group: {
          _id: groupBy,
          totalAmount: { $sum: '$amount' },
          count: { $sum: 1 },
          averageAmount: { $avg: '$amount' },
        },
      },
      {
        $project: {
          _id: 0,
          date: { $toDate: '$_id' },
          totalAmount: 1,
          count: 1,
          averageAmount: 1,
        },
      },
      {
        $sort: { date: 1 },
      },
    ]);

    const previousPeriod = await this.expenseModel.aggregate([
      {
        $match: {
          date: {
            $gte: new Date(startDate.getTime() - (endDate.getTime() - startDate.getTime())),
            $lt: startDate,
          },
        },
      },
      {
        $group: {
          _id: null,
          totalAmount: { $sum: '$amount' },
          count: { $sum: 1 },
          averageAmount: { $avg: '$amount' },
        },
      },
    ]);

    const currentPeriod = await this.expenseModel.aggregate([
      {
        $match: {
          date: { $gte: startDate, $lte: endDate },
        },
      },
      {
        $group: {
          _id: null,
          totalAmount: { $sum: '$amount' },
          count: { $sum: 1 },
          averageAmount: { $avg: '$amount' },
        },
      },
    ]);

    const trend = previousPeriod[0]?.averageAmount
      ? ((currentPeriod[0]?.averageAmount || 0) - previousPeriod[0].averageAmount) /
        previousPeriod[0].averageAmount
      : 0;

    return {
      interval,
      data: trendData,
      dateRange: { startDate, endDate },
      summary: {
        totalAmount: currentPeriod[0]?.totalAmount || 0,
        totalCount: currentPeriod[0]?.count || 0,
        averageAmount: currentPeriod[0]?.averageAmount || 0,
        trend,
      },
    };
  }

  async getExpenseForecast(
    startDate: Date,
    endDate: Date,
  ): Promise<ExpenseForecastDto> {
    const historicalData = await this.expenseModel.aggregate([
      {
        $match: {
          date: { $gte: startDate, $lte: endDate },
        },
      },
      {
        $group: {
          _id: { $dateToString: { format: '%Y-%m-%d', date: '$date' } },
          amount: { $sum: '$amount' },
        },
      },
      {
        $project: {
          _id: 0,
          date: { $toDate: '$_id' },
          amount: 1,
        },
      },
      {
        $sort: { date: 1 },
      },
    ]);

    // Simple moving average forecast
    const windowSize = 7; // 7-day moving average
    const forecast: ExpenseForecastPointDto[] = [];
    const historicalAverage = historicalData.reduce((sum, point) => sum + point.amount, 0) / historicalData.length;

    for (let i = 0; i < 30; i++) {
      const date = new Date(endDate);
      date.setDate(date.getDate() + i + 1);

      const predictedAmount = historicalAverage;
      const confidence = 0.7; // Fixed confidence level for simple forecast
      const margin = predictedAmount * 0.1; // 10% margin for confidence interval

      forecast.push({
        date,
        predictedAmount,
        confidenceInterval: {
          lower: predictedAmount - margin,
          upper: predictedAmount + margin,
        },
      });
    }

    return {
      historicalData,
      forecast,
      dateRange: { startDate, endDate },
      summary: {
        averageAmount: historicalAverage,
        predictedAverage: historicalAverage,
        trend: 0, // No trend in simple moving average
        confidence: 0.7,
      },
    };
  }

  async findByRoom(roomId: string): Promise<Expense[]> {
    return this.expenseModel.find({ roomId }).exec();
  }

  async rejectExpense(id: string): Promise<Expense> {
    const expense = await this.expenseModel.findById(id).exec();
    if (!expense) {
      throw new NotFoundException(`Expense with ID ${id} not found`);
    }

    if (expense.status !== ExpenseStatus.PENDING) {
      throw new BadRequestException('Only pending expenses can be rejected');
    }

    expense.status = ExpenseStatus.REJECTED;
    return expense.save();
  }
} 