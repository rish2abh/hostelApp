export class ExpenseTrendPointDto {
  date: Date;
  totalAmount: number;
  count: number;
  averageAmount: number;
}

export class ExpenseTrendDto {
  interval: 'day' | 'week' | 'month';
  data: ExpenseTrendPointDto[];
  dateRange: {
    startDate: Date;
    endDate: Date;
  };
  summary: {
    totalAmount: number;
    totalCount: number;
    averageAmount: number;
    trend: number; // Percentage change from previous period
  };
} 