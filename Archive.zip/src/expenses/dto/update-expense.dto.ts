import { ApiProperty, PartialType, OmitType } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString } from 'class-validator';
import { CreateExpenseDto } from './create-expense.dto';
import { ExpenseStatus } from '../../entities/expense.entity';

export class UpdateExpenseDto extends PartialType(
  OmitType(CreateExpenseDto, ['createdBy'] as const)
) {
  @ApiProperty({
    enum: ExpenseStatus,
    example: ExpenseStatus.APPROVED,
    description: 'Updated status of the expense',
    required: false
  })
  @IsEnum(ExpenseStatus)
  @IsOptional()
  status?: ExpenseStatus;

  @ApiProperty({
    example: '507f1f77bcf86cd799439013',
    description: 'ID of the user who approved this expense',
    required: false
  })
  @IsString()
  @IsOptional()
  approvedBy?: string;
} 