import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNumber, IsEnum, IsOptional, IsObject, IsDate, Min } from 'class-validator';
import { Type } from 'class-transformer';
import { ExpenseCategory } from '../../entities/expense.entity';

export class CreateExpenseDto {
  @ApiProperty({
    example: '507f1f77bcf86cd799439011',
    description: 'ID of the room associated with this expense',
    required: false
  })
  @IsString()
  @IsOptional()
  roomId?: string;

  @ApiProperty({
    example: 15000,
    description: 'Amount of the expense in the smallest currency unit (e.g., cents)',
    minimum: 0
  })
  @IsNumber()
  @Min(0)
  amount: number;

  @ApiProperty({
    enum: ExpenseCategory,
    example: ExpenseCategory.MAINTENANCE,
    description: 'Category of the expense'
  })
  @IsEnum(ExpenseCategory)
  category: ExpenseCategory;

  @ApiProperty({
    example: 'Monthly maintenance for Room 101',
    description: 'Description of the expense'
  })
  @IsString()
  description: string;

  @ApiProperty({
    example: 'receipt-2024-03-25.pdf',
    description: 'URL or path to the expense receipt',
    required: false
  })
  @IsString()
  @IsOptional()
  receiptUrl?: string;

  @ApiProperty({
    example: '2024-03-25',
    description: 'Date when the expense occurred'
  })
  @IsDate()
  @Type(() => Date)
  expenseDate: Date;

  @ApiProperty({
    example: { notes: 'Urgent repair required', priority: 'high' },
    description: 'Additional metadata about the expense',
    required: false
  })
  @IsObject()
  @IsOptional()
  metadata?: Record<string, any>;
} 