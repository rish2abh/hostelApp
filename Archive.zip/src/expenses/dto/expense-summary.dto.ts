import { ExpenseCategory } from '../../entities/expense.entity';

export class CategorySummaryDto {
  category: ExpenseCategory;
  totalAmount: number;
  count: number;
  averageAmount: number;
  minAmount: number;
  maxAmount: number;
  paymentStatusBreakdown: {
    pending: number;
    paid: number;
    overdue: number;
  };
}

export class ExpenseSummaryDto {
  totalExpenses: number;
  totalCount: number;
  averageExpense: number;
  minExpense: number;
  maxExpense: number;
  categoryBreakdown: CategorySummaryDto[];
  dateRange: {
    startDate: Date;
    endDate: Date;
  };
  paymentStatusBreakdown: {
    pending: number;
    paid: number;
    overdue: number;
  };
} 