export class ExpenseForecastPointDto {
  date: Date;
  predictedAmount: number;
  confidenceInterval: {
    lower: number;
    upper: number;
  };
}

export class ExpenseForecastDto {
  historicalData: {
    date: Date;
    amount: number;
  }[];
  forecast: ExpenseForecastPointDto[];
  dateRange: {
    startDate: Date;
    endDate: Date;
  };
  summary: {
    averageAmount: number;
    predictedAverage: number;
    trend: number; // Percentage change from historical average
    confidence: number; // Confidence level of the forecast (0-1)
  };
} 