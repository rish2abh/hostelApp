import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
  Req,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiParam, ApiQuery } from '@nestjs/swagger';
import { ExpensesService } from './expenses.service';
import { CreateExpenseDto } from './dto/create-expense.dto';
import { UpdateExpenseDto } from './dto/update-expense.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { UserRole } from '../entities/user.entity';
import { Expense, ExpenseStatus, ExpenseCategory } from '../entities/expense.entity';

@ApiTags('Expenses')
@ApiBearerAuth()
@Controller('expenses')
@UseGuards(JwtAuthGuard, RolesGuard)
export class ExpensesController {
  constructor(private readonly expensesService: ExpensesService) {}

  @Post()
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  @ApiOperation({ 
    summary: 'Create expense',
    description: 'Create a new expense record. Only accessible by ADMIN and SUPER_ADMIN roles.'
  })
  @ApiResponse({ 
    status: 201, 
    description: 'Expense has been successfully created.',
    type: Expense 
  })
  @ApiResponse({ 
    status: 400, 
    description: 'Bad request - validation error or invalid data provided.' 
  })
  @ApiResponse({ 
    status: 401, 
    description: 'Unauthorized - JWT token is missing or invalid.' 
  })
  @ApiResponse({ 
    status: 403, 
    description: 'Forbidden - user does not have required roles.' 
  })
  create(@Body() createExpenseDto: CreateExpenseDto) {
    return this.expensesService.create(createExpenseDto);
  }

  @Get()
  @ApiOperation({ 
    summary: 'Get all expenses',
    description: 'Retrieve all expenses with optional filtering and pagination.'
  })
  @ApiQuery({ 
    name: 'status', 
    enum: ExpenseStatus, 
    required: false,
    description: 'Filter expenses by status' 
  })
  @ApiQuery({ 
    name: 'category', 
    enum: ExpenseCategory, 
    required: false,
    description: 'Filter expenses by category' 
  })
  @ApiQuery({ 
    name: 'roomId', 
    required: false,
    description: 'Filter expenses by room ID' 
  })
  @ApiQuery({ 
    name: 'startDate', 
    required: false,
    description: 'Filter expenses by start date' 
  })
  @ApiQuery({ 
    name: 'endDate', 
    required: false,
    description: 'Filter expenses by end date' 
  })
  @ApiQuery({ 
    name: 'page', 
    required: false,
    type: Number,
    description: 'Page number for pagination' 
  })
  @ApiQuery({ 
    name: 'limit', 
    required: false,
    type: Number,
    description: 'Number of items per page' 
  })
  @ApiResponse({ 
    status: 200, 
    description: 'List of expenses.',
    type: [Expense] 
  })
  findAll(
    @Query('status') status?: ExpenseStatus,
    @Query('category') category?: ExpenseCategory,
    @Query('roomId') roomId?: string,
    @Query('startDate') startDate?: Date,
    @Query('endDate') endDate?: Date,
    @Query('page') page = 1,
    @Query('limit') limit = 10,
  ) {
    return this.expensesService.findAll({ 
      status, 
      category, 
      roomId, 
      startDate, 
      endDate, 
      page, 
      limit 
    });
  }

  @Get(':id')
  @ApiOperation({ 
    summary: 'Get expense',
    description: 'Retrieve details of a specific expense by ID.'
  })
  @ApiParam({ 
    name: 'id', 
    description: 'Expense ID',
    type: String,
    example: '507f1f77bcf86cd799439011'
  })
  @ApiResponse({ 
    status: 200, 
    description: 'The expense details.',
    type: Expense 
  })
  @ApiResponse({ 
    status: 404, 
    description: 'Expense not found.' 
  })
  findOne(@Param('id') id: string) {
    return this.expensesService.findOne(id);
  }

  @Put(':id')
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  @ApiOperation({ 
    summary: 'Update expense',
    description: 'Update an expense record. Only accessible by ADMIN and SUPER_ADMIN roles.'
  })
  @ApiParam({ 
    name: 'id', 
    description: 'Expense ID',
    type: String,
    example: '507f1f77bcf86cd799439011'
  })
  @ApiResponse({ 
    status: 200, 
    description: 'Expense has been successfully updated.',
    type: Expense 
  })
  @ApiResponse({ 
    status: 404, 
    description: 'Expense not found.' 
  })
  @ApiResponse({ 
    status: 403, 
    description: 'Forbidden - user does not have required roles.' 
  })
  update(@Param('id') id: string, @Body() updateExpenseDto: UpdateExpenseDto) {
    return this.expensesService.update(id, updateExpenseDto);
  }

  @Delete(':id')
  @Roles(UserRole.SUPER_ADMIN)
  @ApiOperation({ 
    summary: 'Delete expense',
    description: 'Delete an expense record. Only accessible by SUPER_ADMIN role.'
  })
  @ApiParam({ 
    name: 'id', 
    description: 'Expense ID',
    type: String,
    example: '507f1f77bcf86cd799439011'
  })
  @ApiResponse({ 
    status: 200, 
    description: 'Expense has been successfully deleted.',
    type: Expense 
  })
  @ApiResponse({ 
    status: 404, 
    description: 'Expense not found.' 
  })
  @ApiResponse({ 
    status: 403, 
    description: 'Forbidden - user does not have required roles.' 
  })
  remove(@Param('id') id: string) {
    return this.expensesService.remove(id);
  }

  @Get('room/:roomId')
  @ApiOperation({ 
    summary: 'Get room expenses',
    description: 'Retrieve all expenses for a specific room.'
  })
  @ApiParam({ 
    name: 'roomId', 
    description: 'Room ID',
    type: String,
    example: '507f1f77bcf86cd799439011'
  })
  @ApiResponse({ 
    status: 200, 
    description: 'List of expenses for the room.',
    type: [Expense] 
  })
  @ApiResponse({ 
    status: 404, 
    description: 'Room not found.' 
  })
  findByRoom(@Param('roomId') roomId: string) {
    return this.expensesService.findByRoom(roomId);
  }

  @Put(':id/approve')
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  @ApiOperation({ 
    summary: 'Approve expense',
    description: 'Approve an expense. Only accessible by ADMIN and SUPER_ADMIN roles.'
  })
  @ApiParam({ 
    name: 'id', 
    description: 'Expense ID',
    type: String,
    example: '507f1f77bcf86cd799439011'
  })
  @ApiResponse({ 
    status: 200, 
    description: 'Expense has been successfully approved.',
    type: Expense 
  })
  @ApiResponse({ 
    status: 404, 
    description: 'Expense not found.' 
  })
  @ApiResponse({ 
    status: 403, 
    description: 'Forbidden - user does not have required roles.' 
  })
  approveExpense(@Param('id') id: string) {
    return this.expensesService.approveExpense(id);
  }

  @Put(':id/reject')
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  @ApiOperation({ 
    summary: 'Reject expense',
    description: 'Reject an expense. Only accessible by ADMIN and SUPER_ADMIN roles.'
  })
  @ApiParam({ 
    name: 'id', 
    description: 'Expense ID',
    type: String,
    example: '507f1f77bcf86cd799439011'
  })
  @ApiResponse({ 
    status: 200, 
    description: 'Expense has been successfully rejected.',
    type: Expense 
  })
  @ApiResponse({ 
    status: 404, 
    description: 'Expense not found.' 
  })
  @ApiResponse({ 
    status: 403, 
    description: 'Forbidden - user does not have required roles.' 
  })
  rejectExpense(@Param('id') id: string) {
    return this.expensesService.rejectExpense(id);
  }

  @Get('summary')
  getExpenseSummary(
    @Query('startDate') startDate: string,
    @Query('endDate') endDate: string,
  ) {
    return this.expensesService.getExpenseSummary(
      new Date(startDate),
      new Date(endDate),
    );
  }

  @Get('trend')
  getExpenseTrend(
    @Query('startDate') startDate: string,
    @Query('endDate') endDate: string,
    @Query('interval') interval: 'day' | 'week' | 'month' = 'month',
  ) {
    return this.expensesService.getExpenseTrend(
      new Date(startDate),
      new Date(endDate),
      interval,
    );
  }

  @Get('forecast')
  getExpenseForecast(
    @Query('startDate') startDate: string,
    @Query('endDate') endDate: string,
  ) {
    return this.expensesService.getExpenseForecast(
      new Date(startDate),
      new Date(endDate),
    );
  }

  @Get('category/:category')
  findByCategory(@Param('category') category: ExpenseCategory) {
    return this.expensesService.findByCategory(category);
  }

  @Get('date-range')
  findByDateRange(
    @Query('startDate') startDate: string,
    @Query('endDate') endDate: string,
  ) {
    return this.expensesService.findByDateRange(
      new Date(startDate),
      new Date(endDate),
    );
  }
} 