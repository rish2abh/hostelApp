import { IsString, IsNotEmpty, IsEnum, IsOptional, IsMongoId } from 'class-validator';
import { BedStatus } from '../../entities/bed.entity';

export class CreateBedDto {
  @IsString()
  @IsNotEmpty()
  bedNumber: string;

  @IsMongoId()
  @IsNotEmpty()
  roomId: string;

  @IsEnum(BedStatus)
  @IsOptional()
  status?: BedStatus;

  @IsMongoId()
  @IsOptional()
  assignedUser?: string;
} 